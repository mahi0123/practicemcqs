import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchProductsComponent } from '../search-products/search-products.component';
import { SearchCustomersComponent } from '../search-customers/search-customers.component';


const routes: Routes = [

  
    {path:'search-products',component: SearchProductsComponent},
// {path:'list-emp',component:ListEmpComponent}
    // path: 'search',
    // component: SearchProductsComponent
    {path:'search-customers',component: SearchCustomersComponent}
]
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],


  exports: [RouterModule],
  declarations: []
})
  
export class AppRoutingModule { }
