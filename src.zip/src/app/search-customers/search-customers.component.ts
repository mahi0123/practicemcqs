// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-search-customers',
//   templateUrl: './search-customers.component.html',
//   styleUrls: ['./search-customers.component.css']
// })
// export class SearchCustomersComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

import { FormGroup, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/Product.model';

import { ProductService, customerService } from '../service/product.service';


@Component({
  selector: 'app-search-Customers',
  templateUrl: './search-Customers.component.html',
  styleUrls: ['./search-Customers.component.css']
})
export class SearchCustomersComponent  implements OnInit {
 
  
  searchCustomerForm: FormGroup;
  customers: Customer[];
  //name:string;
  CustomersByCategory: Customer[];
  public searchText2:any;
  constructor(private fb: FormBuilder,private CustomerServ:customerService) { }

  ngOnInit() {

    this.searchCustomerForm = this.fb.group({
      category: []
    });
    this.CustomerServ.getcustomers()

    .subscribe(data=>{ //subscribe method observes all the changes and update teh changes
  
    //this.Customers = this.Customers.filter(u=> u.cname==this.name);
  
    this.customers=data
  
     });
  }
 
}
