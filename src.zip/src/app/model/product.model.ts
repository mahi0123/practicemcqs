import { Time } from "../../../node_modules/@angular/common";

export class Product {
   
pname:string;
pprice: number;
ratings: string;
discount: number;

feedback: string;

}

export class Customer{

    cid:number;
    cname: string;
    mobileNumber: number;
    email: string;
    passwod: string;
    date: Date;
    loginTime: Time;
    logoutTime: Time;
    refNumber: number;


} 