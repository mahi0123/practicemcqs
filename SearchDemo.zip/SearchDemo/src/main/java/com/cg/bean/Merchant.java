package com.cg.bean;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement 
@Entity
@Table(name="Merchant")
public class Merchant 
{
	@Id
	@Column(name="Mid",length=10)
	private int merchantId;
	@Column(name="Mname",length=40)
	private String merchantName;
	@Column(name="MOBILENUMBER")
	private String mobileNumber;
	
	
	@Column(name="email",length=40)
	private String email;
	
	@Column(name="password",length=40)
	private String password;
	
	@Column(name="catogory")
	private String catogory;
	
	@Column(name="productName",length=40)
	private String productName;
	
	@Column(name="created_date")
    @Temporal(TemporalType.DATE)
	private Date addMerchantDate;
	//@Column(length=1)
	//private boolean isThirdPartyMerchant;
	
	@Column(name="logintime")
	@Transient
   // @Temporal(TemporalType.TIMESTAMP)
	private java.sql.Timestamp logintime;
	
	@Column(name="logouttime")
	@Transient
   // @Temporal(TemporalType.TIMESTAMP)
	private java.sql.Timestamp logouttime;
	
	
	
	
	//@Column(length=40)
	//private Date removeMerchantDate;
	
	//@Column(length=40)
//	private String merchantStatus;
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public Date getAddMerchantDate() {
		return addMerchantDate;
	}
	public void setAddMerchantDate(Date addMerchantDate) {
		this.addMerchantDate = addMerchantDate;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCatogory() {
		return catogory;
	}
	public void setCatogory(String catogory) {
		this.catogory = catogory;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public java.sql.Timestamp getLogintime() {
		return logintime;
	}
	public void setLogintime(java.sql.Timestamp logintime) {
		this.logintime = logintime;
	}
	public java.sql.Timestamp getLogouttime() {
		return logouttime;
	}
	public void setLogouttime(java.sql.Timestamp logouttime) {
		this.logouttime = logouttime;
	}
	@Override
	public String toString() {
		return "Merchant [merchantId=" + merchantId + ", merchantName=" + merchantName + ", mobileNumber="
				+ mobileNumber + ", email=" + email + ", password=" + password + ", catogory=" + catogory
				+ ", productName=" + productName + ", addMerchantDate=" + addMerchantDate + "]";
	}
	
	
}
