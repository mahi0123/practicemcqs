package com.cg.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="customer")
public class Customer 
{
	@Id
	 private int cid;
	 @Column(name="CNAME")
	 private String cname;
	 @Column(name="CMOBILENUMBER")
	 private String mobileNumber;
	 @Column(name="CEMAIL")
	 private String email;
	 @Column(name="PASSWORD")
	 private String passwod;
	 @Column(name="CREATED_DATE")
	 @Temporal(TemporalType.DATE)
	 private Date date;
 @Column(name="LOGINTIME")
 @Temporal(TemporalType.TIME)
 private Date loginTime;
 @Column(name="LOGOUTTIME")
 @Temporal(TemporalType.TIME)
 private Date logoutTime;
 @Column(name="REFERENCENUMBER")
private int refNumber;
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPasswod() {
	return passwod;
}
public void setPasswod(String passwod) {
	this.passwod = passwod;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
public Date getLoginTime() {
	return loginTime;
}
public void setLoginTime(Date loginTime) {
	this.loginTime = loginTime;
}
public Date getLogoutTime() {
	return logoutTime;
}
public void setLogoutTime(Date logoutTime) {
	this.logoutTime = logoutTime;
}
public int getRefNumber() {
	return refNumber;
}
public void setRefNumber(int refNumber) {
	this.refNumber = refNumber;
}
@Override
public String toString() {
	return "Customer [cid=" + cid + ", cname=" + cname + ", mobileNumber=" + mobileNumber + ", email=" + email
			+ ", passwod=" + passwod + ", date=" + date + ", loginTime=" + loginTime + ", logoutTime=" + logoutTime
			+ ", refNumber=" + refNumber + "]";
}
 
}
