package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="product")
public class Product 
{
	@Id
	 @Column(name="pid")
private Integer pid;
 @Column(name="pname")
	 private String pname;
	 @Column(name="price")
	 private Integer pprice;
 @Column(name="imageurl")
	// @Column(name="purl")
	 private String purl;
 @Column
 @Transient
 private String catogory;
 @Column
 @Transient
 private String model;
 @Column(name="uploada_date")
 @Transient
 private String uploadadata;
 @Column(name="quantity")
 @Transient
 private String qnty;
 @Column(name="description")
 @Transient
 private String description;
	 @Column(name="ratings")
	 private String ratings;
	 @Column(name="discount")
	 private Integer discount;
	 @Column(name="promocode")
	 @Transient
	 private String promocode;
	 @Column(name="mid")
	 @Transient
	 private String mid;
	 @Column(name="feedback")
	 private String feedback;
	 @Column(name="oid")
	 @Transient
	 private String oid;
	 @Column(name="catid")
	 @Transient
	 private String catid;
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public Integer getPprice() {
		return pprice;
	}
	public void setPprice(Integer pprice) {
		this.pprice = pprice;
	}
	public String getPurl() {
		return purl;
	}
	public void setPurl(String purl) {
		this.purl = purl;
	}
	public String getCatogory() {
		return catogory;
	}
	public void setCatogory(String catogory) {
		this.catogory = catogory;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getUploadadata() {
		return uploadadata;
	}
	public void setUploadadata(String uploadadata) {
		this.uploadadata = uploadadata;
	}
	public String getQnty() {
		return qnty;
	}
	public void setQnty(String qnty) {
		this.qnty = qnty;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRatings() {
		return ratings;
	}
	public void setRatings(String ratings) {
		this.ratings = ratings;
	}
	public Integer getDiscount() {
		return discount;
	}
	public void setDiscount(Integer discount) {
		this.discount = discount;
	}
	public String getPromocode() {
		return promocode;
	}
	public void setPromocode(String promocode) {
		this.promocode = promocode;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getCatid() {
		return catid;
	}
	public void setCatid(String catid) {
		this.catid = catid;
	}
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", pprice=" + pprice + ", purl=" + purl + ", catogory="
				+ catogory + ", model=" + model + ", uploadadata=" + uploadadata + ", qnty=" + qnty + ", description="
				+ description + ", ratings=" + ratings + ", discount=" + discount + ", promocode=" + promocode
				+ ", mid=" + mid + ", feedback=" + feedback + ", oid=" + oid + ", catid=" + catid + "]";
	}
	 
	 


}
