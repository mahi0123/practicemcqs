package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Customer;
import com.cg.bean.Merchant;
import com.cg.bean.Product;
import com.cg.dao.ICustomer;
import com.cg.dao.IMerchant;
import com.cg.dao.IProduct;

@Service
public class ServiceImpl implements IService {
@Autowired private IMerchant dao;
@Autowired private ICustomer cdao;
@Autowired private IProduct pdao;
	
	
	public Merchant getid(Integer id) {
		// TODO Auto-generated method stub
		
		return dao.findById(id).get();
	}


	@Transactional
	public Customer getCustomer(Integer id) {
		// TODO Auto-generated method stub
		return cdao.findById(id).get();
	}


	@Override
	public Product getProduct(Integer id) {
		// TODO Auto-generated method stub
		return pdao.findById(id).get();
	}


	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return pdao.findAll();
	}


	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return cdao.findAll();
	}


	@Override
	public List<Merchant> getAllMerchant() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

}
