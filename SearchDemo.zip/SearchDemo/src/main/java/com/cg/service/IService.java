package com.cg.service;

import java.util.List;

import com.cg.bean.Customer;
import com.cg.bean.Merchant;
import com.cg.bean.Product;

public interface IService 
{

Merchant getid(Integer id);
Customer getCustomer(Integer id);
Product getProduct(Integer id);
List<Product>getAllProducts();
List<Customer>getAllCustomer();
List<Merchant>getAllMerchant();
}
