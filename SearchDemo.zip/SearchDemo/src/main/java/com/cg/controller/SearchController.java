package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Customer;
import com.cg.bean.Merchant;
import com.cg.bean.Product;
import com.cg.service.IService;

@RestController
@RequestMapping
public class SearchController 
{
	@Autowired IService service;
@GetMapping(value="/merchant{id}")
public Merchant getMerchant(@PathVariable Integer id) {
	return service.getid(id);
	
}
@GetMapping(value="/customer{id}")
public Customer getCustomer(@PathVariable Integer id) {
	return service.getCustomer(id);
	
}
@GetMapping(value="/product{id}")
public Product getProduct(@PathVariable Integer id) {
	return service.getProduct(id);
	
}
@GetMapping("/findallproducts")

public List<Product> findAllProducts() {

List<Product> product = service.getAllProducts();

return product;

}
@GetMapping("/findallcustomer")

public List<Customer> findAllCustomer() {

List<Customer> customer = service.getAllCustomer();

return customer;

}
@GetMapping("/findallmerchant")

public List<Merchant> findAllMerchant() {

List<Merchant> merchant = service.getAllMerchant();

return merchant;

}
}
