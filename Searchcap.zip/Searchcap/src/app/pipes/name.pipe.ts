import { Pipe, PipeTransform } from '@angular/core';
import { Product } from '../model/product.model';

@Pipe({
  name: 'name'
})
export class NamePipe implements PipeTransform {

  transform(usersList: any, searchText: any){
    if(searchText)
 return  usersList.filter(x=>(x.pname).toLowerCase().startsWith(searchText.toLowerCase()));
   
  //usersList= usersList.filter(x=>(x.cname).toLowerCase().startsWith(searchText.toLowerCase()));
    
   //return usersList.filter(x=>x.cname.toLowerCase().startsWith(searchText.toLowerCase())
  
  return usersList;
  }

//   transform(List: any, searchText: any){
//     if(searchText)

//  return  usersList.filter(x=>(x.pname).toLowerCase().startsWith(searchText.toLowerCase()));
//   //usersList= usersList.filter(x=>(x.cname).toLowerCase().startsWith(searchText.toLowerCase()));
    
//    //return usersList.filter(x=>x.cname.toLowerCase().startsWith(searchText.toLowerCase())
  
//   return usersList;
//   }
 
}
  

  

 
