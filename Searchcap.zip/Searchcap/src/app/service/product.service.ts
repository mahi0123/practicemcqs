import { Product, Customer } from './../model/product.model';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {


  productAPI: string='http://localhost:9090/findallproducts';
  constructor(private http: HttpClient) {  }
  

  // getProducts() {
  //   return this.http.get<Product[]>(this.productAPI+'/findall');
  // }
  //get products
  getallProducts(){
    return this.http.get<Product[]>(this.productAPI);
  }
}

@Injectable({
  providedIn: 'root'
})
export class customerService {

  customerAPI: string='http://localhost:9090/findallcustomer';
  constructor(private http: HttpClient) {  }

  getcustomers(){
    return this.http.get<Customer[]>(this.customerAPI);
  }
  getallCustomers(){
    return this.http.get<Customer[]>(this.customerAPI);
  }
  
}
