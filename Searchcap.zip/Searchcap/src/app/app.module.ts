import { AppRoutingModule } from './app-routing/app-routing.module';


import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SearchProductsComponent } from './search-products/search-products.component';

import { HttpClientModule } from '../../node_modules/@angular/common/http';

import { NamePipe } from './pipes/name.pipe';
import {ReactiveFormsModule, FormsModule}from '@angular/forms';
import { SearchCustomersComponent } from './search-customers/search-customers.component';
import { SqrtPipe } from './pipes/sqrt.pipe';

@NgModule({
  declarations: [
    AppComponent,
    SearchProductsComponent,
    NamePipe,
    SqrtPipe,
    SearchCustomersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
